import React from "react";
import { Link } from "react-router-dom";
import { FaChartLine, FaWallet, FaMobile, FaShieldAlt } from "react-icons/fa";

const Home = () => {
  const features = [
    {
      icon: <FaChartLine className="text-4xl text-[#44B2A7]" />, // Teal
      title: "Smart Analytics",
      description:
        "Visualize your spending patterns with interactive charts and insights",
    },
    {
      icon: <FaWallet className="text-4xl text-[#4A4A4A]" />, // Medium Gray
      title: "Budget Management",
      description: "Set and track budgets easily with our intuitive interface",
    },
    {
      icon: <FaMobile className="text-4xl text-[#44B2A7]" />, // Teal
      title: "Mobile Friendly",
      description:
        "Access your expenses anytime, anywhere with our responsive design",
    },
    {
      icon: <FaShieldAlt className="text-4xl text-[#4A4A4A]" />, // Medium Gray
      title: "Secure Platform",
      description: "Your financial data is protected with bank-level security",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#A7C7E7] via-[#B1F0A3] to-[#D9E7E5]">
      {/* Hero Section */}
      <div className="bg-white shadow-md border border-[#E1E1E1] rounded-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-[#2A2A2A] mb-6">
              Take Control of Your{" "}
              <span className="text-[#44B2A7]">Finances</span> {/* Teal */}
            </h1>
            <p className="text-xl text-[#4A4A4A] mb-8 max-w-2xl mx-auto">
              Expense Tracker helps you track expenses, manage budgets, and achieve
              your financial goals with ease.
            </p>
            <div className="flex justify-center space-x-4">
              <Link
                to="/signup"
                className="px-8 py-3 bg-[#44B2A7] text-white rounded-lg hover:bg-[#32A58F] transition-colors"
              >
                Get Started - It's Free
              </Link>
              <Link
                to="/login"
                className="px-8 py-3 bg-[#F7F7F7] text-[#2A2A2A] border border-[#D2D2D2] rounded-lg hover:bg-[#E1E1E1] transition-colors"
              >
                Login
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-3xl font-bold text-center text-[#2A2A2A] mb-12">
          Why Choose ExpenseTracker?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-xl shadow-md border border-[#E1E1E1] hover:shadow-lg transition-shadow"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold text-[#2A2A2A] mb-2">
                {feature.title}
              </h3>
              <p className="text-[#4A4A4A]">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-[#44B2A7]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to Start Managing Your Expenses?
            </h2>
            <p className="text-xl text-[#B5B5B5] mb-8">
              Join thousands of users who trust ExpenseMate for their financial
              management
            </p>
            <Link
              to="/signup"
              className="px-8 py-3 bg-white text-[#44B2A7] rounded-lg hover:bg-[#E1E1E1] transition-colors inline-block"
            >
              Create Free Account
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#2A2A2A] text-[#B5B5B5] py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p>&copy; 2025 ExpenseMate. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Home;
