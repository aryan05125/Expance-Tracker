import React, { useState } from "react";
import axios from "axios";
import toast from "react-hot-toast";

const OTPModal = ({ isOpen, onClose, onVerify, isLoading, email }) => {
  const [otpValue, setOtpValue] = useState("");
  const [localLoading, setLocalLoading] = useState(false);

  if (!isOpen) return null;

  const handleVerification = async () => {
    if (!otpValue || otpValue.length < 3) {
      toast.error("Please enter a valid OTP");
      return;
    }

    try {
      setLocalLoading(true);
      const data = {
        email: email,
        otpcode: otpValue,
      };

      const resp = await axios.post("/api/verify-otp", data);

      if (resp.data.success) {
        toast.success("OTP verified successfully!", {
          duration: 1500,
          position: "bottom-center",
        });
        setOtpValue("");
        onVerify(true);
        onClose();
      }
    } catch (error) {
      toast.error(error.response?.data?.message || "Invalid OTP", {
        duration: 1500,
        position: "bottom-center",
      });
    } finally {
      setLocalLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center z-50">
      <div className="bg-gradient-to-br from-[#A7C7E7] via-[#B1F0A3] to-[#D9E7E5] p-6 rounded-2xl w-96 shadow-xl border border-[#D2D2D2]">
        <h3 className="text-2xl text-[#2A2A2A] font-semibold mb-4">Enter OTP</h3>
        <p className="text-[#4A4A4A] text-sm mb-4">
          Please enter the verification code sent to your email.
        </p>

        <input
          type="text"
          maxLength="6"
          className="w-full pl-4 pr-4 py-3 rounded-xl bg-[#F7F7F7] text-[#2A2A2A] placeholder-[#B5B5B5] border border-[#E1E1E1] focus:outline-none focus:ring-2 focus:ring-[#44B2A7] transition-all"
          placeholder="Enter 4-digit OTP"
          value={otpValue}
          onChange={(e) => setOtpValue(e.target.value.replace(/[^0-9]/g, ""))}
        />

        <div className="flex justify-end mt-6 space-x-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-white bg-[#B5B5B5] rounded-lg hover:bg-[#D2D2D2] transition-all"
            disabled={localLoading}
          >
            Cancel
          </button>
          <button
            onClick={handleVerification}
            className="px-4 py-2 text-white bg-[#44B2A7] rounded-lg hover:bg-[#32A58F] transition-all flex items-center"
            disabled={localLoading || !otpValue}
          >
            {localLoading ? (
              <span className="flex items-center">
                <svg
                  className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  ></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                Verifying...
              </span>
            ) : (
              "Verify OTP"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default OTPModal;
