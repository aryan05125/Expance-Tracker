import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaEnvelope, FaLock } from "react-icons/fa";
import { useForm } from "react-hook-form";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";
import OTPModal from "./OTPModal";

const Loader = () => (
  <div className="flex items-center justify-center">
    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
  </div>
);

const Login = () => {
  const { register, handleSubmit, getValues } = useForm();
  const [isVerified, setisVerified] = useState(false);
  const [isModelOpen, setisModelOpen] = useState(false);
  const [isLoading, setisLoading] = useState(false);
  const navigate = useNavigate();

  const HandleLogin = async (data) => {
    console.log(data);
    try {
      if (isVerified) {
        setisLoading(true);
        const resp = await axios.post("/api/login", data);

        if (resp.status === 200) {
          toast.success("Login Success", {
            duration: 1500,
            position: "bottom-center",
          });

          localStorage.setItem("user_id", resp.data._id);
          localStorage.setItem("name", resp.data.name);
          localStorage.setItem("isAdmin", resp.data.isAdmin);

          setTimeout(() => {
            navigate(resp.data.isAdmin ? "/admin" : "/user");
          }, 1500);
        }
      } else {
        setisLoading(true);
        const resp = await axios.get(`/api/send-otp/${data.email}`);

        if (resp.data) {
          setisModelOpen(true);
          toast.success("OTP sent successfully!", {
            duration: 1500,
            position: "bottom-center",
          });
        }
      }
    } catch (error) {
      toast.error(error.response?.data?.message || "Something went wrong", {
        duration: 1500,
        position: "bottom-center",
      });
      console.error("Error:", error);
    } finally {
      setisLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#A7C7E7] via-[#B1F0A3] to-[#D9E7E5] px-4">
      <div>
        <Toaster />
      </div>
      <div className="bg-white shadow-lg rounded-2xl p-8 w-full max-w-md border border-[#D2D2D2]">
        {/* Header */}
        <div className="text-center">
          <h2 className="text-4xl font-bold text-[#2A2A2A]">Welcome Back!</h2>
          <p className="mt-2 text-[#4A4A4A]">Sign in to your account</p>
        </div>

        {/* Login Form */}
        <form className="mt-8 space-y-6" onSubmit={handleSubmit(HandleLogin)}>
          <div className="space-y-4">
            {/* Email Field */}
            <div className="relative">
              <FaEnvelope className="absolute top-3 left-3 text-[#B5B5B5] text-lg" />
              <input
                id="email"
                name="email"
                type="email"
                required
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#F7F7F7] text-[#2A2A2A] placeholder-[#B5B5B5] border border-[#E1E1E1] focus:outline-none focus:ring-2 focus:ring-[#44B2A7] focus:border-[#44B2A7] transition-all"
                placeholder="Email address"
                {...register("email", { required: true })}
              />
            </div>

            {/* Password Field */}
            <div className="relative">
              <FaLock className="absolute top-3 left-3 text-[#B5B5B5] text-lg" />
              <input
                id="password"
                name="password"
                type="password"
                required
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#F7F7F7] text-[#2A2A2A] placeholder-[#B5B5B5] border border-[#E1E1E1] focus:outline-none focus:ring-2 focus:ring-[#44B2A7] focus:border-[#44B2A7] transition-all"
                placeholder="Password"
                {...register("password", { required: true })}
              />
            </div>
          </div>

          {/* Remember Me & Forgot Password */}
          <div className="flex items-center justify-between text-[#4A4A4A]">
            <label className="flex items-center space-x-2">
              <input
                id="remember-me"
                name="remember-me"
                type="checkbox"
                className="h-4 w-4 rounded-md text-[#44B2A7] focus:ring-[#32A58F] border-[#B5B5B5]"
              />
              <span className="text-sm">Remember me</span>
            </label>

            <Link
              to="/forgot-password"
              className="text-sm text-[#44B2A7] hover:text-[#32A58F] hover:underline transition-all"
            >
              Forgot password?
            </Link>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-[#44B2A7] hover:bg-[#32A58F] text-white font-semibold transition-all duration-200 shadow-md hover:shadow-lg hover:ring-2 hover:ring-[#44B2A7] cursor-pointer"
            disabled={isLoading}
          >
            {isLoading ? <Loader /> : isVerified ? "Sign In" : "Generate OTP"}
          </button>

          <OTPModal
            isOpen={isModelOpen}
            onClose={() => setisModelOpen(false)}
            onVerify={(success) => {
              if (success) {
                setisVerified(true);
              }
            }}
            isLoading={isLoading}
            email={getValues("email")}
          />

          {/* Sign Up Link */}
          <p className="text-center text-sm text-[#4A4A4A]">
            Don't have an account?{" "}
            <Link
              to="/signup"
              className="text-[#44B2A7] font-semibold hover:underline hover:text-[#32A58F] transition-all"
            >
              Sign up
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Login;
