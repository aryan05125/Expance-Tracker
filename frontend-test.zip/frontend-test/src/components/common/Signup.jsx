import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaEnvelope, FaLock } from "react-icons/fa";
import { useForm } from "react-hook-form";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";

const SignUp = () => {
  const { register, handleSubmit } = useForm();
  const navigate = useNavigate();

  const HandleSignUp = async (data) => {
    console.log(data);
    try {
      const resp = await axios.post("/api/signup", data);
      console.log(resp.data);
      if (resp.status === 200) {
        toast.success("Sign Up Success", {
          duration: 1500,
          position: "bottom-center",
          className: "bg-gray-500",
        });
        setTimeout(() => {
          navigate("/login");
        }, 2000);
      }
    } catch (error) {
      toast.error("Error in signing up", {
        duration: 1500,
        position: "bottom-center",
      });
      console.log("Error in sign up" + error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-[#A7C7E7] via-[#B1F0A3] to-[#D9E7E5] px-4">
      <div>
        <Toaster />
      </div>
      <div className="bg-white/90 backdrop-blur-lg shadow-xl rounded-3xl p-8 w-full max-w-md border border-[#D2D2D2]">
        {/* Header */}
        <div className="text-center">
          <h2 className="text-4xl font-bold text-[#2A2A2A]">Create an Account</h2>
          <p className="mt-2 text-[#4A4A4A]">Sign up to get started</p>
        </div>

        {/* Sign Up Form */}
        <form className="mt-8 space-y-6" onSubmit={handleSubmit(HandleSignUp)}>
          <div className="space-y-4">
            {/* Name Field */}
            <div className="relative">
              <FaEnvelope className="absolute top-3 left-3 text-[#44B2A7] text-xl" />
              <input
                id="name"
                name="name"
                type="text"
                required
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#F7F7F7] text-[#2A2A2A] placeholder-[#B5B5B5] border border-[#E1E1E1] focus:outline-none focus:ring-2 focus:ring-[#44B2A7] focus:border-[#44B2A7] transition-all"
                placeholder="Full Name"
                {...register("name", { required: true })}
              />
            </div>

            {/* Email Field */}
            <div className="relative">
              <FaEnvelope className="absolute top-3 left-3 text-[#44B2A7] text-xl" />
              <input
                id="email"
                name="email"
                type="email"
                required
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#F7F7F7] text-[#2A2A2A] placeholder-[#B5B5B5] border border-[#E1E1E1] focus:outline-none focus:ring-2 focus:ring-[#44B2A7] focus:border-[#44B2A7] transition-all"
                placeholder="Email address"
                {...register("email", { required: true })}
              />
            </div>

            {/* Password Field */}
            <div className="relative">
              <FaLock className="absolute top-3 left-3 text-[#44B2A7] text-xl" />
              <input
                id="password"
                name="password"
                type="password"
                required
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-[#F7F7F7] text-[#2A2A2A] placeholder-[#B5B5B5] border border-[#E1E1E1] focus:outline-none focus:ring-2 focus:ring-[#44B2A7] focus:border-[#44B2A7] transition-all"
                placeholder="Password"
                {...register("password", { required: true })}
              />
            </div>
          </div>

          {/* Remember Me & Forgot Password */}
          <div className="flex items-center justify-between text-[#4A4A4A]">
            <label className="flex items-center space-x-2">
              <input
                id="remember-me"
                name="remember-me"
                type="checkbox"
                className="h-4 w-4 rounded-md text-[#44B2A7] focus:ring-[#44B2A7] border-[#E1E1E1]"
              />
              <span className="text-sm">Remember me</span>
            </label>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-gradient-to-r from-[#44B2A7] to-[#32A58F] text-white font-semibold transition-all duration-200 shadow-md hover:shadow-lg hover:ring-2 hover:ring-[#32A58F] cursor-pointer"
          >
            Sign up
          </button>

          {/* Login Link */}
          <p className="text-center text-sm text-[#4A4A4A]">
            Already have an account?{" "}
            <Link
              to="/login"
              className="text-[#44B2A7] font-semibold hover:underline hover:text-[#32A58F] transition-all"
            >
              Sign in
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default SignUp;