import React, { useEffect, useState } from "react";
import {
  FaFilter,
  FaPlus,
  FaArrowUp,
  FaArrowDown,
  FaTrash,
  FaWallet,
} from "react-icons/fa";
import AddExpense from "./AddExpense";
import toast, { Toaster } from "react-hot-toast";
import axios from "axios";
import AddCategory from "./AddCategory";
import { format } from "date-fns";

const Transactions = () => {
  const [filterOpen, setFilterOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [transactions, setTransactions] = useState([]);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [refresh, setRefresh] = useState(false);

  // GET ALL TRANSACTIONS BY USER_ID
  const HandleGetAllTransactions = async () => {
    try {
      const user_id = localStorage.getItem("user_id");
      const resp = await axios.get("/api/transactions/user/" + user_id);

      if (resp.status === 500) {
        toast.error("No Transactions Found");
        return;
      }

      const sortedData = resp.data.sort((a, b) => {
        return new Date(b.date) - new Date(a.date);
      });

      setTransactions(sortedData);
    } catch (error) {
      console.error(error);
    }
  };

  // DELETE TRANSACTION
  const HandleDeleteTransactionbyId = async (id) => {
    try {
      await axios.delete(`/api/transactions/${id}`);
      toast.success("Transaction deleted successfully");
      HandleGetAllTransactions();
      setRefresh((prev) => !prev);
    } catch (error) {
      console.error(error);
      toast.error("Failed to delete transaction");
    }
  };

  useEffect(() => {
    HandleGetAllTransactions();
  }, [refresh]);

  return (
    <div className="p-6 bg-gradient-to-b from-white-50 to-gray-100 min-h-screen">
      <Toaster position="bottom-right" />
      <AddExpense
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setRefresh((prev) => !prev);
        }}
      />
      <AddCategory
        isOpen={isCategoryModalOpen}
        onClose={() => {
          setIsCategoryModalOpen(false);
          setRefresh((prev) => !prev);
        }}
      />

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-3xl font-bold text-blue-700 mb-4 md:mb-0">
          Transactions 💰
        </h1>

        {/* Actions */}
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setFilterOpen(!filterOpen)}
            className="px-4 py-2 flex items-center space-x-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-200 transition"
          >
            <FaFilter className="text-gray-500" />
            <span>Filter</span>
          </button>

          <button
            className="px-4 py-2 flex items-center space-x-2 text-white bg-green-600 hover:bg-green-700 rounded-lg transition"
            onClick={() => setIsCategoryModalOpen(true)}
          >
            <FaPlus />
            <span>Add Category</span>
          </button>

          <button
            className="px-4 py-2 flex items-center space-x-2 text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition"
            onClick={() => setIsModalOpen(true)}
          >
            <FaPlus />
            <span>Add Transaction</span>
          </button>
        </div>
      </div>

      {/* Filter Panel */}
      {filterOpen && (
        <div className="bg-white p-4 rounded-lg shadow-sm mb-6 border-l-4 border-blue-500">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <select className="form-select rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500">
              <option value="">All Types</option>
              <option value="expense">Expense</option>
              <option value="income">Income</option>
            </select>

            <select className="form-select rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500">
              <option value="">All Categories</option>
              <option value="food">Food</option>
              <option value="transport">Transport</option>
              <option value="salary">Salary</option>
            </select>

            <input
              type="date"
              className="form-input rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
            />

            <button className="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700">
              Apply Filters
            </button>
          </div>
        </div>
      )}

      {/* Transactions List */}
      <div className="bg-white rounded-xl shadow-md">
        <div className="grid grid-cols-1 divide-y divide-gray-200">
          {transactions.length > 0 ? (
            transactions?.map((transaction) => (
              <div
                key={transaction._id}
                className="p-4 hover:bg-gray-50 transition-colors duration-150 flex justify-between items-center"
              >
                <div className="flex items-center space-x-4">
                  <div
                    className={`p-3 rounded-lg ${
                      transaction.transaction_type === "Expense"
                        ? "bg-red-100 text-red-700"
                        : "bg-green-100 text-green-700"
                    }`}
                  >
                    {transaction.transaction_type === "Expense" ? (
                      <FaArrowDown />
                    ) : (
                      <FaArrowUp />
                    )}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-800">
                      {transaction.description}
                    </p>
                    <p className="text-sm text-gray-500">
                      {transaction.category_id.name || "Uncategorized"}
                    </p>
                  </div>
                </div>

                {/* Amount & Date */}
                <div className="text-right">
                  <p
                    className={`font-medium ${
                      transaction.transaction_type === "Expense"
                        ? "text-red-600"
                        : "text-green-600"
                    }`}
                  >
                    {transaction.transaction_type === "Expense" ? "-" : "+"}$
                    {transaction.amount}
                  </p>
                  <p className="text-sm text-gray-500">
                    {format(new Date(transaction.date), "MMM dd, yyyy")}
                  </p>
                </div>

                {/* Delete Button */}
                <button
                  onClick={() => {
                    if (
                      window.confirm(
                        "Are you sure you want to delete this transaction?"
                      )
                    ) {
                      HandleDeleteTransactionbyId(transaction._id);
                    }
                  }}
                  className="p-2 text-gray-500 hover:text-red-500 transition"
                >
                  <FaTrash />
                </button>
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-12 bg-gray-50 rounded-lg">
              <FaWallet className="text-gray-400 text-5xl mb-4" />
              <p className="text-gray-500">No transactions found</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Transactions;
