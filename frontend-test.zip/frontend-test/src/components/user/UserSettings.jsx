import React, { useState } from "react";
import {
  FaLock,
  FaBell,
  FaPalette,
  FaDollarSign,
  FaLanguage,
} from "react-icons/fa";

const UserSettings = () => {
  const [activeTab, setActiveTab] = useState("security");

  const settingsSections = {
    security: <SecuritySettings />,
    notifications: <NotificationSettings />,
    preferences: <PreferenceSettings />,
    currency: <CurrencySettings />,
    language: <LanguageSettings />,
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Settings</h1>

        <div className="bg-white rounded-xl shadow-sm">
          {/* Settings Navigation */}
          <div className="border-b border-gray-200">
            <nav className="flex flex-wrap space-x-4 px-6">
              {[
                { key: "security", icon: FaLock, label: "Security" },
                { key: "notifications", icon: FaBell, label: "Notifications" },
                { key: "preferences", icon: FaPalette, label: "Preferences" },
                { key: "currency", icon: FaDollarSign, label: "Currency" },
                { key: "language", icon: FaLanguage, label: "Language" },
              ].map(({ key, icon: Icon, label }) => (
                <button
                  key={key}
                  onClick={() => setActiveTab(key)}
                  className={`py-4 px-2 font-medium border-b-2 transition-colors ${
                    activeTab === key
                      ? "border-green-500 text-green-500"
                      : "border-transparent text-gray-500 hover:text-gray-700"
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Icon />
                    <span>{label}</span>
                  </div>
                </button>
              ))}
            </nav>
          </div>

          {/* Settings Content */}
          <div className="p-6">{settingsSections[activeTab]}</div>
        </div>
      </div>
    </div>
  );
};

// Security Settings Component
const SecuritySettings = () => {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-gray-800">Change Password</h2>
      <form className="space-y-4">
        {[
          { label: "Current Password", value: currentPassword, setValue: setCurrentPassword },
          { label: "New Password", value: newPassword, setValue: setNewPassword },
          { label: "Confirm New Password", value: confirmPassword, setValue: setConfirmPassword },
        ].map(({ label, value, setValue }) => (
          <div key={label}>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {label}
            </label>
            <input
              type="password"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className="w-full p-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
            />
          </div>
        ))}
        <button
          type="submit"
          className="w-full py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
        >
          Update Password
        </button>
      </form>
    </div>
  );
};

// Notification Settings Component
const NotificationSettings = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-gray-800">
        Notification Preferences
      </h2>
      <div className="space-y-4">
        {["Email Notifications", "Push Notifications", "Budget Alerts", "Payment Reminders"].map(
          (setting) => (
            <div key={setting} className="flex items-center justify-between">
              <span className="text-gray-700">{setting}</span>
              <label className="switch">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-green-500"></div>
              </label>
            </div>
          )
        )}
      </div>
    </div>
  );
};

// Preference Settings Component
const PreferenceSettings = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-gray-800">Display Preferences</h2>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Theme</label>
          <select className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500">
            <option value="light">Light</option>
            <option value="dark">Dark</option>
            <option value="system">System</option>
          </select>
        </div>
      </div>
    </div>
  );
};

// Currency Settings Component
const CurrencySettings = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-gray-800">Currency Settings</h2>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Default Currency</label>
        <select className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500">
          <option value="USD">USD - US Dollar</option>
          <option value="EUR">EUR - Euro</option>
          <option value="GBP">GBP - British Pound</option>
          <option value="JPY">JPY - Japanese Yen</option>
        </select>
      </div>
    </div>
  );
};

// Language Settings Component
const LanguageSettings = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-gray-800">Language Settings</h2>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Display Language</label>
        <select className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500">
          <option value="en">English</option>
          <option value="es">Spanish</option>
          <option value="fr">French</option>
          <option value="de">German</option>
        </select>
      </div>
    </div>
  );
};

export default UserSettings;
