import React, { useState } from "react";
import {
  FaLock,
  FaBell,
  FaPalette,
  FaDollarSign,
  FaLanguage,
} from "react-icons/fa";

const AdminSettings = () => {
  const [activeTab, setActiveTab] = useState("security");

  const settingsSections = {
    security: <SecuritySettings />,
    notifications: <NotificationSettings />,
    preferences: <PreferenceSettings />,
    currency: <CurrencySettings />,
    language: <LanguageSettings />,
  };

  return (
    <div className="p-6 bg-green-900 min-h-screen text-white">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold text-green-600 mb-6">Settings</h1>

        <div className="bg-blue-gray-800 rounded-xl shadow-md border border-green-600">
          {/* Navigation */}
          <div className="border-b border-green-600">
            <nav className="flex flex-wrap space-x-4 px-6">
              {[
                { id: "security", icon: <FaLock />, label: "Security" },
                { id: "notifications", icon: <FaBell />, label: "Notifications" },
                { id: "preferences", icon: <FaPalette />, label: "Preferences" },
                { id: "currency", icon: <FaDollarSign />, label: "Currency" },
                { id: "language", icon: <FaLanguage />, label: "Language" },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-2 font-medium border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? "border-green-600 text-green-600"
                      : "border-transparent text-blue-gray-200 hover:text-white"
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    {tab.icon}
                    <span>{tab.label}</span>
                  </div>
                </button>
              ))}
            </nav>
          </div>

          {/* Settings Content */}
          <div className="p-6">{settingsSections[activeTab]}</div>
        </div>
      </div>
    </div>
  );
};

// Security Settings Component
const SecuritySettings = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-green-600">Change Password</h2>
      <form className="space-y-4">
        {["Current Password", "New Password", "Confirm New Password"].map((label, index) => (
          <div key={index}>
            <label className="block text-sm font-medium text-blue-gray-200 mb-2">{label}</label>
            <input
              type="password"
              className="w-full p-3 bg-gray-800 border border-green-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
            />
          </div>
        ))}
        <button className="w-full py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
          Update Password
        </button>
      </form>
    </div>
  );
};

// Notification Settings Component
const NotificationSettings = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-green-600">Notification Preferences</h2>
      <div className="space-y-4">
        {["Email Notifications", "Push Notifications", "Budget Alerts", "Payment Reminders"].map((setting) => (
          <div key={setting} className="flex items-center justify-between">
            <span className="text-blue-gray-200">{setting}</span>
            <label className="switch">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-gray-700 rounded-full peer peer-checked:bg-green-600"></div>
            </label>
          </div>
        ))}
      </div>
    </div>
  );
};

// Preference Settings Component
const PreferenceSettings = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-green-600">Display Preferences</h2>
      <div>
        <label className="block text-sm font-medium text-blue-gray-200 mb-2">Theme</label>
        <select className="w-full p-3 bg-gray-800 border border-green-600 rounded-lg text-white focus:ring-green-500">
          <option value="dark">Dark</option>
          <option value="blue-gray">Blue-Gray</option>
          <option value="green">Green</option>
        </select>
      </div>
    </div>
  );
};

// Currency Settings Component
const CurrencySettings = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-green-600">Currency Settings</h2>
      <div>
        <label className="block text-sm font-medium text-blue-gray-200 mb-2">Default Currency</label>
        <select className="w-full p-3 bg-gray-800 border border-green-600 rounded-lg text-white focus:ring-green-500">
          <option value="USD">USD - US Dollar</option>
          <option value="EUR">EUR - Euro</option>
          <option value="GBP">GBP - British Pound</option>
          <option value="JPY">JPY - Japanese Yen</option>
        </select>
      </div>
    </div>
  );
};

// Language Settings Component
const LanguageSettings = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-green-600">Language Settings</h2>
      <div>
        <label className="block text-sm font-medium text-blue-gray-200 mb-2">Display Language</label>
        <select className="w-full p-3 bg-gray-800 border border-green-600 rounded-lg text-white focus:ring-green-500">
          <option value="en">English</option>
          <option value="es">Spanish</option>
          <option value="fr">French</option>
          <option value="de">German</option>
        </select>
      </div>
    </div>
  );
};

export default AdminSettings;
