import React, { useState, useEffect } from "react";
import {
  FaUsers,
  FaWallet,
  FaChartLine,
  FaExclamationTriangle,
  FaSearch,
  FaFilter,
} from "react-icons/fa";
import axios from "axios";

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const [searchTerm, setSearchTerm] = useState("");
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    totalTransactions: 0,
    flaggedTransactions: 0,
  });

  useEffect(() => {
    HandleGetAllDashboardAnalytics();
  }, []);

  const HandleGetAllDashboardAnalytics = async () => {
    try {
      const respUsers = await axios.get("/api/analytics/users/");
      const respTransactions = await axios.get("/api/analytics/transactions/");
      setStats({
        totalUsers: respUsers.data.TotalUsers,
        activeUsers: respUsers.data.NoOfActiveUsers,
        totalTransactions: respTransactions.data.TotalTransactions,
        flaggedTransactions: respTransactions.data.NoOfInActiveTransactions,
      });
    } catch (error) {
      console.error(error);
    }
  };

  const StatCard = ({ title, value, icon, color }) => (
    <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-all">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-gray-500 text-sm">{title}</p>
          <h3 className="text-2xl font-bold text-gray-800 mt-1">{value}</h3>
        </div>
        <div className={`p-3 rounded-full ${color} bg-opacity-10`}>
          {React.cloneElement(icon, { className: `text-xl ${color}` })}
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-800">Admin Dashboard</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Total Users"
          value={stats.totalUsers}
          icon={<FaUsers />}
          color="text-orange-500"
        />
        <StatCard
          title="Active Users"
          value={stats.activeUsers}
          icon={<FaUsers />}
          color="text-teal-500"
        />
        <StatCard
          title="Total Transactions"
          value={stats.totalTransactions}
          icon={<FaWallet />}
          color="text-indigo-500"
        />
        <StatCard
          title="Flagged Transactions"
          value={stats.flaggedTransactions}
          icon={<FaExclamationTriangle />}
          color="text-rose-500"
        />
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex space-x-4">
            {["overview", "users", "transactions"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-lg transition-all ${
                  activeTab === tab
                    ? "bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-md"
                    : "text-gray-600 hover:bg-gray-200"
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>

          <div className="relative">
            <input
              type="text"
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <FaSearch className="absolute left-3 top-3 text-gray-400" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
